"""
╔══════════════════════════════════════════╗
║        ЩОДЕННИК КЛАСУ  •  v5.1           ║
║     FastAPI + Telegram Bot (Unified)     ║
╚══════════════════════════════════════════╝
"""

import logging
import sqlite3
import os
import secrets
from datetime import datetime, date, timedelta, time
from zoneinfo import ZoneInfo
from contextlib import asynccontextmanager
from typing import List, Dict, Any

from fastapi import FastAPI, Request, UploadFile, File
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from telegram import (
    Update, BotCommand, InlineKeyboardButton, InlineKeyboardMarkup,
    WebAppInfo, MenuButtonWebApp
)
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# ==========================================
# ⚙️ НАЛАШТУВАННЯ
# ================ ==========================
TOKEN = "7577718061:AAGnDtSK8Ou1SXvY4Ivcc5Ht9EHXoYChioE"
if not TOKEN:
    raise RuntimeError("❌ BOT_TOKEN не задано. Встанови змінну середовища BOT_TOKEN")

DB_PATH = "diary.db"
WEB_APP_URL = os.getenv("WEB_APP_URL", "https://nondeep-unhesitantly-donna.ngrok-free.dev")  # <-- Заміни через env

UPLOAD_DIR = "uploads"
MAX_UPLOAD_MB = 60
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024

logging.basicConfig(format="%(asctime)s [%(levelname)s] %(name)s: %(message)s", level=logging.INFO)
log = logging.getLogger(__name__)

KYIV_TZ = ZoneInfo("Europe/Kyiv")

def today_kyiv() -> date:
    return datetime.now(KYIV_TZ).date()

# ==========================================
# 🗄 БАЗА ДАНИХ ТА ДАНІ РОЗКЛАДУ
# ==========================================
DAYS_UA = ["Понеділок","Вівторок","Середа","Четвер","П'ятниця","Субота","Неділя"]

SCHEDULE = {
    "Понеділок": ["Алгебра","Фізика","Інформатика","Фізкультура","Англ. Мова","Біологія","Технології"],
    "Вівторок":  ["Хімія","Геометрія","Укр. Мова","Укр. Літ","Фізкультура","Фізика"],
    "Середа":    ["Укр. Мова","Мистецтво","Укр. Літ","Фізика","Географія","Мистецтво (0.5)"],
    "Четвер":    ["Історія","Алгебра","Хімія","Історія України","Біологія","Інформ./Технол.","Англ. Мова"],
    "П'ятниця":  ["Історія України","Зар. Літ","Астрономія","Укр. Мова (дод)","Фізкультура"],
}

BELLS = [
    (1,"09:00","09:45"),(2,"09:55","10:40"),(3,"10:50","11:35"),
    (4,"11:45","12:30"),(0,"12:30","13:00"),
    (5,"13:00","13:45"),(6,"13:55","14:40"),
    (7,"14:50","15:35"),(8,"15:45","16:30"),
]

EMOJI = {
    "Алгебра":"📐","Геометрія":"📏","Фізика":"⚛️","Хімія":"🧪","Біологія":"🌿",
    "Географія":"🌍","Астрономія":"🔭","Інформатика":"💻","Інформ./Технол.":"💻",
    "Технології":"🔧","Англ. Мова":"🇬🇧","Укр. Мова":"🇺🇦","Укр. Мова (дод)":"🇺🇦",
    "Укр. Літ":"📖","Зар. Літ":"📚","Історія":"🏛️","Історія України":"🏳️",
    "Мистецтво":"🎨","Мистецтво (0.5)":"🎨","Фізкультура":"⚽",
}

def ei(s): return EMOJI.get(s, "📌")
def day_name(d: date): return DAYS_UA[d.weekday()]

def dbc():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON;")
    return c

def init_db():
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    with dbc() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS homework(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject TEXT NOT NULL,
                description TEXT NOT NULL,
                due_date TEXT NOT NULL,
                author_id INTEGER,
                author_name TEXT,
                created_at TEXT DEFAULT (datetime('now','localtime')),
                is_done INTEGER DEFAULT 0
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS subscribers(
                chat_id INTEGER PRIMARY KEY,
                username TEXT,
                mode TEXT DEFAULT 'private',
                title TEXT
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS attachments(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hw_id INTEGER NOT NULL,
                original_name TEXT NOT NULL,
                stored_name TEXT NOT NULL UNIQUE,
                mime_type TEXT,
                size_bytes INTEGER,
                created_at TEXT DEFAULT (datetime('now','localtime')),
                FOREIGN KEY(hw_id) REFERENCES homework(id) ON DELETE CASCADE
            )
        """)

def hw_cleanup():
    cutoff = (today_kyiv() - timedelta(days=3)).isoformat()
    with dbc() as c:
        return c.execute("DELETE FROM homework WHERE due_date < ?", (cutoff,)).rowcount

def sub_get(chat_id):
    with dbc() as c:
        return c.execute("SELECT chat_id,username,mode,title FROM subscribers WHERE chat_id=?", (chat_id,)).fetchone()

def sub_add(chat_id, username, mode="private", title=None):
    with dbc() as c:
        c.execute(
            "INSERT OR REPLACE INTO subscribers(chat_id,username,mode,title) VALUES(?,?,?,?)",
            (chat_id, username, mode, title)
        )

def sub_remove(chat_id):
    with dbc() as c:
        c.execute("DELETE FROM subscribers WHERE chat_id=?", (chat_id,))

def sub_all():
    with dbc() as c:
        return c.execute("SELECT chat_id FROM subscribers").fetchall()

def _attachments_for_hw_ids(ids: List[int]) -> Dict[int, List[Dict[str, Any]]]:
    if not ids:
        return {}
    q_marks = ",".join(["?"] * len(ids))
    with dbc() as c:
        rows = c.execute(
            f"""
            SELECT id, hw_id, original_name, stored_name, mime_type, size_bytes
            FROM attachments
            WHERE hw_id IN ({q_marks})
            ORDER BY id
            """,
            ids
        ).fetchall()

    out: Dict[int, List[Dict[str, Any]]] = {}
    for r in rows:
        hw_id = int(r["hw_id"])
        out.setdefault(hw_id, []).append({
            "id": int(r["id"]),
            "name": r["original_name"],
            "url": f"/files/{r['stored_name']}",
            "mime": r["mime_type"] or "",
            "size": int(r["size_bytes"] or 0),
        })
    return out

def hw_for_date_formatted(d: str):
    with dbc() as c:
        rows = c.execute("""
            SELECT id, subject, description, due_date, author_name, author_id
            FROM homework
            WHERE due_date=?
            ORDER BY subject
        """, (d,)).fetchall()

    ids = [int(r["id"]) for r in rows]
    att_map = _attachments_for_hw_ids(ids)

    return [{
        "id": int(r["id"]),
        "subject": r["subject"],
        "description": r["description"],
        "author": r["author_name"] or "—",
        "author_id": r["author_id"],
        "attachments": att_map.get(int(r["id"]), [])
    } for r in rows]

def _safe_ext(filename: str) -> str:
    _, ext = os.path.splitext(filename or "")
    ext = (ext or "").lower().strip()
    if len(ext) > 12:
        return ""
    return ext

def _delete_file_quiet(stored_name: str):
    try:
        path = os.path.join(UPLOAD_DIR, stored_name)
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass

# ==========================================
# 🤖 ТЕЛЕГРАМ БОТ (Меню)
# ==========================================
DIV = "▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔"
HEADER_MAIN  = f"📚 *Щоденник Класу*\n{DIV}\nОбери розділ:"
HEADER_SCHED = f"📆 *Розклад уроків*\n{DIV}\nОбери день:"

def kb(*rows): return InlineKeyboardMarkup(list(rows))
def _back(cb="go_main", label="◀️  Назад"): return InlineKeyboardButton(label, callback_data=cb)

def kb_main():
    return kb(
        [InlineKeyboardButton("📱 Відкрити Щоденник", web_app=WebAppInfo(url=WEB_APP_URL))],
        [InlineKeyboardButton("📆  Розклад",            callback_data="menu_schedule")],
        [InlineKeyboardButton("🔔  Підписка",           callback_data="menu_sub")],
        [InlineKeyboardButton("❓  Допомога",           callback_data="help")],
        [InlineKeyboardButton("✖  Закрити меню",       callback_data="close_menu")],
    )

def kb_schedule_days():
    btns = [InlineKeyboardButton(d, callback_data=f"sched_{d}") for d in SCHEDULE]
    rows = [[btns[i], btns[i+1]] if i+1 < len(btns) else [btns[i]] for i in range(0, len(btns), 2)]
    rows.append([_back()])
    return InlineKeyboardMarkup(rows)

def kb_sub(is_sub: bool):
    rows = [
        [InlineKeyboardButton("👤  Приватно (цей чат)",   callback_data="sub_private")],
        [InlineKeyboardButton("👥  В групу — інструкція", callback_data="sub_group_info")],
    ]
    if is_sub:
        rows.append([InlineKeyboardButton("🚫  Скасувати підписку", callback_data="sub_cancel")])
    rows.append([_back()])
    return InlineKeyboardMarkup(rows)

async def delete_msg(msg):
    try:
        await msg.delete()
    except Exception:
        pass

async def go_main(q, ctx):
    await q.edit_message_text(HEADER_MAIN, parse_mode="Markdown", reply_markup=kb_main())

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    chat = update.effective_chat
    title = chat.title if chat.type != "private" else None

    if not sub_get(chat.id):
        sub_add(chat.id, u.username or u.first_name, "private" if chat.type == "private" else "group", title)

    greeting = (
        f"👋 Вітаємо, *{u.first_name}*!\n\n📚 *Щоденник Класу* — офіційний бот класу.\n{DIV}\n"
        f"Тут зберігається домашнє завдання,\nрозклад уроків і нагадування.\n\nОбери розділ:"
    ) if chat.type == "private" else (
        f"📚 *Щоденник Класу* підключено!\n{DIV}\nНагадування надходитимуть щодня о *09:00*."
    )

    await update.message.reply_text(greeting, parse_mode="Markdown", reply_markup=kb_main())
    await delete_msg(update.message)

async def cmd_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(HEADER_MAIN, parse_mode="Markdown", reply_markup=kb_main())
    await delete_msg(update.message)

async def cmd_schedule(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(HEADER_SCHED, parse_mode="Markdown", reply_markup=kb_schedule_days())
    await delete_msg(update.message)

async def cb_go_main(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await go_main(q, ctx)

async def cb_close_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer("Меню закрито ✖")
    try:
        await q.message.delete()
    except Exception:
        await q.edit_message_reply_markup(reply_markup=None)

async def cb_menu_schedule(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text(HEADER_SCHED, parse_mode="Markdown", reply_markup=kb_schedule_days())

async def cb_sched_day(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    day = q.data.replace("sched_", "")
    subjects = SCHEDULE.get(day, [])
    text = f"📆 *{day}*\n{DIV}\n\n"
    lesson_num = 0
    for num, start, end in BELLS:
        if num == 0:
            text += f"\n╭─ 🍽  *Обідня перерва*\n╰─ {start} – {end}\n\n"
        else:
            lesson_num += 1
            if lesson_num - 1 < len(subjects):
                subj = subjects[lesson_num - 1]
                text += f"╭─ *{num}.* {ei(subj)} {subj}\n╰─ {start} – {end}\n"

    await q.edit_message_text(
        text,
        parse_mode="Markdown",
        reply_markup=kb([_back("menu_schedule", "◀️  До розкладу")], [_back()])
    )

async def cb_menu_sub(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    rec = sub_get(update.effective_chat.id)
    status = f"✅ *Активна* — {'в групу 👥' if rec and rec['mode']=='group' else 'приватно 👤'}" if rec else "❌ *Не активна*"
    await q.edit_message_text(
        f"🔔 *Підписка*\n{DIV}\n\nСтатус: {status}\n\nЩодня о *09:00* надходить список Д/З на поточний день.",
        parse_mode="Markdown",
        reply_markup=kb_sub(bool(rec))
    )

async def cb_sub_private(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if update.effective_chat.type != "private":
        return await q.answer("⚠️ Тільки в приватному чаті!", show_alert=True)
    sub_add(update.effective_chat.id, update.effective_user.first_name, "private")
    await q.edit_message_text(
        f"✅ *Підписку оформлено!*\n{DIV}\n\n👤 Нагадування щодня о *09:00*.",
        parse_mode="Markdown",
        reply_markup=kb([_back()])
    )

async def cb_sub_group_info(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text(
        f"👥 *Підписка групи*\n{DIV}\n\n1️⃣  Додай бота до групи\n2️⃣  Напиши в групі /start\n3️⃣  Готово\n\n💡 Група отримуватиме Д/З о *09:00*.",
        parse_mode="Markdown",
        reply_markup=kb([_back("menu_sub")])
    )

async def cb_sub_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    sub_remove(update.effective_chat.id)
    await q.edit_message_text(
        f"🚫 *Підписку скасовано*\n{DIV}\n\nРанкові нагадування вимкнено.",
        parse_mode="Markdown",
        reply_markup=kb([_back()])
    )

async def cb_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text(
        f"❓ *Довідка*\n{DIV}\n\n"
        "📱 *Щоденник* — відкриває міні-додаток, де зберігаються всі завдання.\n\n"
        "📎 *Вкладення* — можна додати pdf/фото/відео до завдання.\n\n"
        "📆 *Розклад* — уроки і час дзвінків по днях тижня.\n"
        "🔔 *Підписка* — щоденне нагадування про Д/З о 09:00.\n"
        f"{DIV}\n"
        "🤖 *Команди:*\n"
        "/menu — головне меню\n"
        "/schedule — розклад\n\n"
        "🧹 Старі завдання автоматично видаляються.",
        parse_mode="Markdown",
        reply_markup=kb([_back()])
    )

async def job_morning(ctx: ContextTypes.DEFAULT_TYPE):
    today = today_kyiv()
    rows = hw_for_date_formatted(today.isoformat())
    dn = day_name(today)
    if rows:
        text = f"☀️ *Доброго ранку!*\n📅 *{DAYS_UA[today.weekday()]}, {today.strftime('%d.%m')}*\n{DIV}\n\n"
        for r in rows:
            clip = "📎" if r.get("attachments") else ""
            text += f"╭─ {ei(r['subject'])} *{r['subject']}* {clip}\n│  📋 {r['description']}\n╰─ 👤 {r['author']}\n\n"
    else:
        text = f"☀️ *Доброго ранку!*\n\n📭 На сьогодні (*{dn}*) Д/З немає 🎉\nВідпочивай!"

    for rec in sub_all():
        chat_id = rec[0] if isinstance(rec, (tuple, list)) else rec["chat_id"]
        try:
            await ctx.bot.send_message(chat_id, text, parse_mode="Markdown")
        except Exception as ex:
            log.warning("Reminder failed %s: %s", chat_id, ex)

async def job_cleanup(ctx: ContextTypes.DEFAULT_TYPE):
    n = hw_cleanup()
    if n:
        log.info("🧹 Автоочищення: %d Д/З видалено", n)

# ==========================================
# 🌐 FASTAPI + INTEGRATION
# ==========================================
ptb_app = Application.builder().token(TOKEN).build()

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()

    await ptb_app.bot.set_my_commands([
        BotCommand("start",    "🚀 Запустити бота"),
        BotCommand("menu",     "📚 Головне меню"),
        BotCommand("schedule", "📆 Розклад уроків"),
    ])
    await ptb_app.bot.set_chat_menu_button(
        menu_button=MenuButtonWebApp(text="📱 Щоденник", web_app=WebAppInfo(url=WEB_APP_URL))
    )

    ptb_app.add_handler(CommandHandler("start",    cmd_start))
    ptb_app.add_handler(CommandHandler("menu",     cmd_menu))
    ptb_app.add_handler(CommandHandler("schedule", cmd_schedule))
    ptb_app.add_handler(CallbackQueryHandler(cb_close_menu,     pattern="^close_menu$"))
    ptb_app.add_handler(CallbackQueryHandler(cb_go_main,        pattern="^go_main$"))
    ptb_app.add_handler(CallbackQueryHandler(cb_menu_schedule,  pattern="^menu_schedule$"))
    ptb_app.add_handler(CallbackQueryHandler(cb_sched_day,      pattern="^sched_"))
    ptb_app.add_handler(CallbackQueryHandler(cb_menu_sub,       pattern="^menu_sub$"))
    ptb_app.add_handler(CallbackQueryHandler(cb_sub_private,    pattern="^sub_private$"))
    ptb_app.add_handler(CallbackQueryHandler(cb_sub_group_info, pattern="^sub_group_info$"))
    ptb_app.add_handler(CallbackQueryHandler(cb_sub_cancel,     pattern="^sub_cancel$"))
    ptb_app.add_handler(CallbackQueryHandler(cb_help,           pattern="^help$"))

    jq = ptb_app.job_queue
    jq.run_daily(job_morning, time=time(hour=9, minute=0, tzinfo=KYIV_TZ))
    jq.run_daily(job_cleanup, time=time(hour=0, minute=5, tzinfo=KYIV_TZ))

    await ptb_app.initialize()
    await ptb_app.start()
    await ptb_app.updater.start_polling()
    log.info("🚀 Telegram Бот працює паралельно з FastAPI!")

    yield

    await ptb_app.updater.stop()
    await ptb_app.stop()
    await ptb_app.shutdown()

fastapi_app = FastAPI(lifespan=lifespan)

@fastapi_app.get("/files/{stored_name}")
async def get_file(stored_name: str):
    path = os.path.join(UPLOAD_DIR, stored_name)
    if not os.path.exists(path):
        return JSONResponse({"status": "error", "message": "File not found"}, status_code=404)
    return FileResponse(path, filename=stored_name)

@fastapi_app.get("/", response_class=HTMLResponse)
async def read_root():
    with open("templates/index.html", "r", encoding="utf-8") as f:
        return f.read()

@fastapi_app.get("/api/hw")
async def get_hw_api():
    today = today_kyiv()
    data = {}
    for i in range(3):
        target_date = today + timedelta(days=i)
        iso_date = target_date.isoformat()
        label = "Сьогодні" if i == 0 else "Завтра" if i == 1 else target_date.strftime('%d.%m')
        data[iso_date] = {"label": label, "tasks": hw_for_date_formatted(iso_date)}
    return data

@fastapi_app.get("/api/hw_all")
async def get_hw_all_api():
    start = (today_kyiv() - timedelta(days=2)).isoformat()
    if not os.path.exists(DB_PATH):
        return []
    with dbc() as c:
        rows = c.execute("""
            SELECT id, subject, description, author_name, author_id, due_date
            FROM homework
            WHERE due_date >= ?
            ORDER BY due_date, subject
        """, (start,)).fetchall()

    ids = [int(r["id"]) for r in rows]
    att_map = _attachments_for_hw_ids(ids)

    return [{
        "id": int(r["id"]),
        "subject": r["subject"],
        "description": r["description"],
        "author": r["author_name"] or "—",
        "author_id": r["author_id"],
        "date": r["due_date"],
        "attachments": att_map.get(int(r["id"]), [])
    } for r in rows]

@fastapi_app.post("/api/upload")
async def api_upload(files: List[UploadFile] = File(...)):
    os.makedirs(UPLOAD_DIR, exist_ok=True)

    uploaded = []
    total = 0

    for f in files:
        data = await f.read()
        size = len(data)
        total += size

        if size == 0:
            continue
        if total > MAX_UPLOAD_BYTES:
            return JSONResponse({"status":"error","message":f"Занадто великий upload (max {MAX_UPLOAD_MB}MB)"}, status_code=413)

        ext = _safe_ext(f.filename)
        token = secrets.token_hex(16)
        stored = f"{token}{ext}"

        path = os.path.join(UPLOAD_DIR, stored)
        with open(path, "wb") as out:
            out.write(data)

        uploaded.append({
            "name": f.filename,
            "stored_name": stored,
            "url": f"/files/{stored}",
            "mime": f.content_type or "",
            "size": size,
        })

    return {"status": "ok", "files": uploaded}

@fastapi_app.post("/api/hw_add")
async def api_add_hw(request: Request):
    data = await request.json()
    subject = data.get("subject")
    desc = data.get("description")
    due = data.get("date")
    author = data.get("author", "Mini App")
    author_id = data.get("author_id")
    attachments = data.get("attachments") or []

    if subject and desc and due:
        with dbc() as c:
            cur = c.execute("""
                INSERT INTO homework(subject, description, due_date, author_name, author_id)
                VALUES(?,?,?,?,?)
            """, (subject, desc, due, author, author_id))
            hw_id = int(cur.lastrowid)

            for a in attachments:
                stored_name = a.get("stored_name")
                orig = a.get("name") or "file"
                mime = a.get("mime") or ""
                size = int(a.get("size") or 0)

                if not stored_name:
                    continue
                path = os.path.join(UPLOAD_DIR, stored_name)
                if not os.path.exists(path):
                    continue

                c.execute("""
                    INSERT OR IGNORE INTO attachments(hw_id, original_name, stored_name, mime_type, size_bytes)
                    VALUES(?,?,?,?,?)
                """, (hw_id, orig, stored_name, mime, size))

    return {"status": "ok"}

@fastapi_app.post("/api/hw_delete")
async def api_delete_hw(request: Request):
    data = await request.json()
    hw_id = data.get("id")
    if not hw_id:
        return {"status": "error", "message": "No ID provided"}

    with dbc() as c:
        rows = c.execute("SELECT stored_name FROM attachments WHERE hw_id=?", (hw_id,)).fetchall()
        for r in rows:
            _delete_file_quiet(r["stored_name"])
        c.execute("DELETE FROM homework WHERE id=?", (hw_id,))

    return {"status": "ok"}

@fastapi_app.post("/api/hw_update")
async def api_update_hw(request: Request):
    data = await request.json()
    hw_id = data.get("id")
    subject = data.get("subject")
    due = data.get("date")
    desc = data.get("description")
    attachments = data.get("attachments")

    if not hw_id:
        return {"status": "error", "message": "No ID provided"}
    if not (subject and due and desc):
        return {"status": "error", "message": "Invalid data"}

    with dbc() as c:
        c.execute("""
            UPDATE homework
            SET subject=?, due_date=?, description=?
            WHERE id=?
        """, (subject, due, desc, hw_id))

        if attachments is not None:
            kept_names = {a.get("stored_name") for a in (attachments or []) if a.get("stored_name")}
            old = c.execute("SELECT stored_name FROM attachments WHERE hw_id=?", (hw_id,)).fetchall()
            for r in old:
                if r["stored_name"] not in kept_names:
                    _delete_file_quiet(r["stored_name"])

            c.execute("DELETE FROM attachments WHERE hw_id=?", (hw_id,))

            for a in (attachments or []):
                stored_name = a.get("stored_name")
                orig = a.get("name") or "file"
                mime = a.get("mime") or ""
                size = int(a.get("size") or 0)
                if not stored_name:
                    continue
                path = os.path.join(UPLOAD_DIR, stored_name)
                if not os.path.exists(path):
                    continue
                c.execute("""
                    INSERT OR IGNORE INTO attachments(hw_id, original_name, stored_name, mime_type, size_bytes)
                    VALUES(?,?,?,?,?)
                """, (hw_id, orig, stored_name, mime, size))

    return {"status": "ok"}

# ==========================================
# 🚀 RUN
# ==========================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(fastapi_app, host="0.0.0.0", port=8000)
